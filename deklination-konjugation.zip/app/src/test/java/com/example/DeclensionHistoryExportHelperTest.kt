package com.example

import com.example.data.model.DeclensionCaseRow
import com.example.data.model.DeclensionTableGroup
import com.example.data.model.WordDeclensionResult
import com.example.util.DeclensionHistoryExportHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.zip.ZipFile

class DeclensionHistoryExportHelperTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private fun createSampleWord(word: String, article: String, plural: String, meaning: String): WordDeclensionResult {
        val singularRows = listOf(
            DeclensionCaseRow("nominativ", "Nominativ", "Wer oder was?", "$article $word", "ein $word", word),
            DeclensionCaseRow("akkusativ", "Akkusativ", "Wen oder was?", "$article $word", "einen $word", word),
            DeclensionCaseRow("dativ", "Dativ", "Wem?", "dem $word", "einem $word", word),
            DeclensionCaseRow("genitiv", "Genitiv", "Wessen?", "des ${word}s", "eines ${word}s", "${word}s")
        )
        val pluralRows = listOf(
            DeclensionCaseRow("nominativ", "Nominativ", "Wer oder was?", plural, "keine", word),
            DeclensionCaseRow("akkusativ", "Akkusativ", "Wen oder was?", plural, "keine", word),
            DeclensionCaseRow("dativ", "Dativ", "Wem?", "den ${word}n", "keinen", "${word}n"),
            DeclensionCaseRow("genitiv", "Genitiv", "Wessen?", "der $plural", "keiner", word)
        )
        return WordDeclensionResult(
            word = word,
            gender = if (article == "das") "Neutrum" else "Maskulin",
            genderArticle = article,
            pluralNoun = plural,
            meaningEnglish = meaning,
            singular = DeclensionTableGroup("Singular", singularRows),
            plural = DeclensionTableGroup("Plural", pluralRows)
        )
    }

    @Test
    fun testDeduplicationAndRowStructure() {
        val word1 = createSampleWord("Schloss", "das", "die Schlösser", "castle / lock")
        val word1Duplicate = createSampleWord("schloss", "das", "die Schlösser", "castle / lock")
        val word2 = createSampleWord("Tisch", "der", "die Tische", "table")

        val rows = DeclensionHistoryExportHelper.buildDeduplicatedRows(listOf(word1, word1Duplicate, word2))

        // Duplicates must be removed; each searched word in a single continuous row
        assertEquals(2, rows.size)

        val r1 = rows[0]
        assertEquals("das Schloss", r1.nomenSingular)
        assertEquals("die Schlösser", r1.plural)
        assertEquals("castle / lock", r1.englishTranslation)
        assertTrue(r1.nominativ.contains("das Schloss") && r1.nominativ.contains("die Schlösser"))
        assertTrue(r1.akkusativ.contains("das Schloss") && r1.akkusativ.contains("die Schlösser"))
        assertTrue(r1.genitiv.contains("des Schlosses") || r1.genitiv.contains("Schloss"))
        assertTrue(r1.dativ.contains("dem Schloss") && r1.dativ.contains("den Schlossn"))
        assertEquals("Neutrum", r1.genus)
    }

    @Test
    fun testCreateXlsxFile_producesValidZipAndSheetStructure() {
        val word = createSampleWord("Schloss", "das", "die Schlösser", "castle / lock")
        val file = tempFolder.newFile("test_export.xlsx")
        val customTitle = "Mein_Export_Titel"

        DeclensionHistoryExportHelper.createXlsxFile(file, listOf(word), customTitle)

        assertTrue(file.exists() && file.length() > 0)

        // Verify it is a valid Zip file containing the required OpenXML components
        ZipFile(file).use { zip ->
            val sheetEntry = zip.getEntry("xl/worksheets/sheet1.xml")
            org.junit.Assert.assertNotNull(sheetEntry)

            val sheetContent = zip.getInputStream(sheetEntry).bufferedReader().readText()
            // Title matches custom title in Cell A1
            assertTrue(sheetContent.contains(customTitle))
            // No extra subtitle/description text in the sheet
            org.junit.Assert.assertFalse(sheetContent.contains("Gesamter Suchverlauf in fortlaufenden Zeilen"))
            org.junit.Assert.assertFalse(sheetContent.contains("Deutsche Konjugationstabellen"))

            assertTrue(sheetContent.contains("Nomen (Singular)"))
            assertTrue(sheetContent.contains("Plural"))
            assertTrue(sheetContent.contains("English translation"))
            assertTrue(sheetContent.contains("Nominativ (Sg./Pl.)"))
            assertTrue(sheetContent.contains("Akkusativ (Sg./Pl.)"))
            assertTrue(sheetContent.contains("Genitiv (Sg./Pl.)"))
            assertTrue(sheetContent.contains("Dativ (Sg./Pl.)"))
            org.junit.Assert.assertFalse(sheetContent.contains("Ablativ"))
            assertTrue(sheetContent.contains("Genus"))
            assertTrue(sheetContent.contains("autoFilter"))
            assertTrue(sheetContent.contains("das Schloss"))
            assertTrue(sheetContent.contains("die Schlösser"))

            // Verify workbook sheet name matches custom title
            val workbookEntry = zip.getEntry("xl/workbook.xml")
            org.junit.Assert.assertNotNull(workbookEntry)
            val workbookContent = zip.getInputStream(workbookEntry).bufferedReader().readText()
            assertTrue(workbookContent.contains("name=\"$customTitle\""))
        }
    }

    @Test
    fun testGenerateLandscapePrintableHtml() {
        val word = createSampleWord("Schloss", "das", "die Schlösser", "castle / lock")
        val customTitle = "Custom_Suchverlauf"
        val html = DeclensionHistoryExportHelper.generateLandscapePrintableHtml(listOf(word), customTitle)

        assertTrue(html.contains("size: A4 landscape"))
        assertTrue(html.contains("<title>$customTitle</title>"))
        assertTrue(html.contains("<h1>$customTitle</h1>"))
        org.junit.Assert.assertFalse(html.contains("class=\"subtitle\""))
        org.junit.Assert.assertFalse(html.contains("Horizontale Übersicht der gesuchten Nomen"))
        assertTrue(html.contains("Nomen (Singular)"))
        assertTrue(html.contains("Plural"))
        assertTrue(html.contains("English translation"))
        org.junit.Assert.assertFalse(html.contains("Ablativ"))
        assertTrue(html.contains("das Schloss"))
        assertTrue(html.contains("die Schlösser"))
        assertTrue(html.contains("castle / lock"))
    }

    @Test
    fun testSanitizeFileName() {
        assertEquals("Suchverlauf_Deutsch", com.example.util.ExportSharingManager.sanitizeFileName(""))
        assertEquals("Suchverlauf_Deutsch", com.example.util.ExportSharingManager.sanitizeFileName("   "))
        assertEquals("Meine_Woerter", com.example.util.ExportSharingManager.sanitizeFileName("Meine_Woerter.xlsx"))
        assertEquals("Meine_Woerter", com.example.util.ExportSharingManager.sanitizeFileName("Meine_Woerter.pdf"))
        assertEquals("Meine_Woerter___", com.example.util.ExportSharingManager.sanitizeFileName("Meine/Woerter:*?"))
    }

    private fun createSampleVerb(verb: String): com.example.data.model.VerbConjugationResult {
        val tenses = listOf(
            com.example.data.model.VerbTenseConjugation(
                tenseKey = "praesens", tenseNameDe = "Präsens",
                ich = "nehme", du = "nimmst", erSieEs = "nimmt",
                wir = "nehmen", ihr = "nehmt", sieSie = "nehmen"
            ),
            com.example.data.model.VerbTenseConjugation(
                tenseKey = "praeteritum", tenseNameDe = "Präteritum",
                ich = "nahm", du = "nahmst", erSieEs = "nahm",
                wir = "nahmen", ihr = "nahmt", sieSie = "nahmen"
            ),
            com.example.data.model.VerbTenseConjugation(
                tenseKey = "perfekt", tenseNameDe = "Perfekt",
                ich = "habe genommen", du = "hast genommen", erSieEs = "hat genommen",
                wir = "haben genommen", ihr = "habt genommen", sieSie = "haben genommen"
            ),
            com.example.data.model.VerbTenseConjugation(
                tenseKey = "plusquamperfekt", tenseNameDe = "Plusquamperfekt",
                ich = "hatte genommen", du = "hattest genommen", erSieEs = "hatte genommen",
                wir = "hatten genommen", ihr = "hattet genommen", sieSie = "hatten genommen"
            ),
            com.example.data.model.VerbTenseConjugation(
                tenseKey = "futur1", tenseNameDe = "Futur I",
                ich = "werde nehmen", du = "wirst nehmen", erSieEs = "wird nehmen",
                wir = "werden nehmen", ihr = "werdet nehmen", sieSie = "werden nehmen"
            ),
            com.example.data.model.VerbTenseConjugation(
                tenseKey = "futur2", tenseNameDe = "Futur II",
                ich = "werde genommen haben", du = "wirst genommen haben", erSieEs = "wird genommen haben",
                wir = "werden genommen haben", ihr = "werdet genommen haben", sieSie = "werden genommen haben"
            )
        )
        return com.example.data.model.VerbConjugationResult(
            word = verb,
            infinitiv = verb,
            hilfsverb = "haben",
            partizip1 = "${verb}end",
            partizip2 = "ge${verb}t",
            meaningEnglish = "to $verb",
            imperativ = com.example.data.model.VerbImperativ(
                du = "nimm",
                ihr = "nehmt",
                sie = "nehmen Sie"
            ),
            tenses = tenses
        )
    }

    @Test
    fun testBuildMasterVerbRows_Exact8ColumnsAnd7RowsPerVerb() {
        val verb1 = createSampleVerb("nehmen")
        val verb2 = createSampleVerb("fahren")
        val duplicateVerb1 = createSampleVerb("nehmen")

        val masterRows = DeclensionHistoryExportHelper.buildMasterVerbRows(listOf(verb1, duplicateVerb1, verb2))

        // Deduplicated: 2 unique verbs * 7 rows = 14 rows total
        assertEquals(14, masterRows.size)

        // Headers
        assertEquals(8, DeclensionHistoryExportHelper.VERB_MASTER_HEADERS.size)
        assertEquals("Verb (Infinitiv)", DeclensionHistoryExportHelper.VERB_MASTER_HEADERS[0])
        assertEquals("Zeit (Tense)", DeclensionHistoryExportHelper.VERB_MASTER_HEADERS[1])
        assertEquals("ich", DeclensionHistoryExportHelper.VERB_MASTER_HEADERS[2])
        assertEquals("du", DeclensionHistoryExportHelper.VERB_MASTER_HEADERS[3])
        assertEquals("er/sie/es", DeclensionHistoryExportHelper.VERB_MASTER_HEADERS[4])
        assertEquals("wir", DeclensionHistoryExportHelper.VERB_MASTER_HEADERS[5])
        assertEquals("ihr", DeclensionHistoryExportHelper.VERB_MASTER_HEADERS[6])
        assertEquals("sie/Sie", DeclensionHistoryExportHelper.VERB_MASTER_HEADERS[7])

        // First verb: nehmen - 7 tenses
        val expectedTenses = listOf("Präsens", "Präteritum", "Perfekt", "Plusquamperfekt", "Futur I", "Futur II", "Imperativ")
        for (i in 0..6) {
            val row = masterRows[i]
            assertEquals("nehmen", row.infinitiv)
            assertEquals(expectedTenses[i], row.zeit)
            assertEquals(8, row.toList().size)
        }

        // Check Imperativ row specifics
        val imperativRow = masterRows[6]
        assertEquals("—", imperativRow.ich)
        assertEquals("nimm", imperativRow.du)
        assertEquals("—", imperativRow.erSieEs)
        assertEquals("—", imperativRow.wir)
        assertEquals("nehmt", imperativRow.ihr)
        assertEquals("nehmen Sie", imperativRow.sieSie)
        assertTrue(imperativRow.isLastRowOfVerb)

        // Check second verb: fahren
        assertEquals("fahren", masterRows[7].infinitiv)
        assertEquals("Präsens", masterRows[7].zeit)
    }

    @Test
    fun testPaperSizeOptions_Dimensions() {
        // Verify paper sizes have positive dimensions and correct landscape aspect ratio
        for (option in DeclensionHistoryExportHelper.PaperSizeOption.values()) {
            assertTrue(option.widthPt > 0)
            assertTrue(option.heightPt > 0)
            if (option.isLandscape) {
                assertTrue(option.widthPt >= option.heightPt)
            } else {
                assertTrue(option.heightPt >= option.widthPt)
            }
        }
    }
}
