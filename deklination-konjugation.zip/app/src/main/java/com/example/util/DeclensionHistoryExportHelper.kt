package com.example.util

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.data.model.WordDeclensionResult
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Generates horizontal, adjacent German noun declension tables for:
 * 1. Microsoft Excel (.xlsx - real native OpenXML workbook with formatted header fill, filters, auto-column widths).
 * 2. Standalone PDF document (Android native PdfDocument in true LANDSCAPE orientation with styled tables and pagination).
 * 3. System Print & PDF Spooler (Android PrintManager via WebView in Landscape orientation).
 * 4. UTF-8 BOM CSV / TSV fallback.
 *
 * Guaranteed data structure:
 * - Each searched word is recorded in a SINGLE continuous row.
 * - Deduplication is enforced (no repeated words).
 * - Exact German adjacent columns in order:
 *   1. Nomen (Singular)
 *   2. Plural
 *   3. English translation
 *   4. Nominativ (Singular / Plural)
 *   5. Akkusativ (Singular / Plural)
 *   6. Genitiv (Singular / Plural)
 *   7. Dativ (Singular / Plural)
 *   8. Ablativ (Singular / Plural)
 */
object DeclensionHistoryExportHelper {

    val HEADERS = listOf(
        "Nomen (Singular)",
        "Plural",
        "English translation",
        "Nominativ (Sg./Pl.)",
        "Akkusativ (Sg./Pl.)",
        "Genitiv (Sg./Pl.)",
        "Dativ (Sg./Pl.)",
        "Genus"
    )

    val VERB_HEADERS = listOf(
        "Infinitiv",
        "Hilfsverb",
        "Partizip I",
        "Partizip II",
        "English translation",
        "Präsens",
        "Präteritum",
        "Perfekt",
        "Plusquamperfekt",
        "Futur I",
        "Futur II",
        "Imperativ"
    )

    /**
     * Fixed 8 columns for the Unified Master Verb Table in PDF and Excel:
     * Verb (Infinitiv) | Zeit (Tense) | ich | du | er/sie/es | wir | ihr | sie/Sie
     */
    val VERB_MASTER_HEADERS = listOf(
        "Verb (Infinitiv)",
        "Zeit (Tense)",
        "ich",
        "du",
        "er/sie/es",
        "wir",
        "ihr",
        "sie/Sie"
    )

    /**
     * Paper size options with standardized dimensions (in PostScript points for PDF)
     * and dynamic font sizes according to approved specifications:
     * - A3 / Letter Landscape / A4 Landscape: 10pt - 11pt
     * - A4 Portrait / Letter Portrait: 8pt - 9pt
     * - A5 (any orientation): 6pt - 7pt
     */
    enum class PaperSizeOption(
        val label: String,
        val widthMm: Int,
        val heightMm: Int,
        val isLandscape: Boolean,
        val defaultFontSizePt: Float,
        val headerFontSizePt: Float
    ) {
        A3_LANDSCAPE("A3 (Querformat)", 420, 297, true, 10.5f, 11.5f),
        A3_PORTRAIT("A3 (Hochformat)", 297, 420, false, 9.5f, 10.5f),
        A4_LANDSCAPE("A4 (Querformat)", 297, 210, true, 10.0f, 11.0f),
        A4_PORTRAIT("A4 (Hochformat)", 210, 297, false, 8.5f, 9.5f),
        A5_LANDSCAPE("A5 (Querformat)", 210, 148, true, 7.0f, 8.0f),
        A5_PORTRAIT("A5 (Hochformat)", 148, 210, false, 6.5f, 7.5f),
        LETTER_LANDSCAPE("Letter (Querformat)", 279, 216, true, 10.0f, 11.0f),
        LETTER_PORTRAIT("Letter (Hochformat)", 216, 279, false, 8.5f, 9.5f);

        val widthPt: Int get() = when (this) {
            A3_LANDSCAPE -> 1191
            A3_PORTRAIT -> 842
            A4_LANDSCAPE -> 842
            A4_PORTRAIT -> 595
            A5_LANDSCAPE -> 595
            A5_PORTRAIT -> 420
            LETTER_LANDSCAPE -> 792
            LETTER_PORTRAIT -> 612
        }

        val heightPt: Int get() = when (this) {
            A3_LANDSCAPE -> 842
            A3_PORTRAIT -> 1191
            A4_LANDSCAPE -> 595
            A4_PORTRAIT -> 842
            A5_LANDSCAPE -> 420
            A5_PORTRAIT -> 595
            LETTER_LANDSCAPE -> 612
            LETTER_PORTRAIT -> 792
        }

        companion object {
            val DEFAULT = A4_PORTRAIT
        }
    }

    enum class ExportScope(val displayName: String) {
        NOMEN("Nomen"),
        VERB("Verb"),
        ALLE("Alle");

        companion object {
            fun fromString(str: String?): ExportScope = when (str?.trim()?.lowercase()) {
                "verb", "verben" -> VERB
                "alle", "all" -> ALLE
                else -> NOMEN
            }
        }
    }

    data class WordExportRow(
        val nomenSingular: String,
        val plural: String,
        val englishTranslation: String,
        val nominativ: String,
        val akkusativ: String,
        val genitiv: String,
        val dativ: String,
        val genus: String
    ) {
        fun toList(): List<String> = listOf(
            nomenSingular,
            plural,
            englishTranslation,
            nominativ,
            akkusativ,
            genitiv,
            dativ,
            genus
        )
    }

    data class VerbExportRow(
        val infinitiv: String,
        val hilfsverb: String,
        val partizip1: String,
        val partizip2: String,
        val englishTranslation: String,
        val praesens: String,
        val praeteritum: String,
        val perfekt: String,
        val plusquamperfekt: String,
        val futur1: String,
        val futur2: String,
        val imperativ: String
    ) {
        fun toList(): List<String> = listOf(
            infinitiv,
            hilfsverb,
            partizip1,
            partizip2,
            englishTranslation,
            praesens,
            praeteritum,
            perfekt,
            plusquamperfekt,
            futur1,
            futur2,
            imperativ
        )
    }

    data class VerbMasterRow(
        val infinitiv: String,
        val zeit: String,
        val ich: String,
        val du: String,
        val erSieEs: String,
        val wir: String,
        val ihr: String,
        val sieSie: String,
        val isLastRowOfVerb: Boolean = false
    ) {
        fun toList(): List<String> = listOf(
            infinitiv,
            zeit,
            ich,
            du,
            erSieEs,
            wir,
            ihr,
            sieSie
        )
    }

    /**
     * Builds the unified master verb table rows according to approved specifications:
     * - Deduplication: Duplicate searches of a verb appear only once.
     * - Order: Chronological by first search timestamp (oldest first).
     * - 7 rows per verb: Präsens, Präteritum, Perfekt, Plusquamperfekt, Futur I, Futur II, Imperativ.
     * - Pronouns: Clean conjugated forms matching: ich, du, er/sie/es, wir, ihr, sie/Sie.
     * - Imperativ: du form, ihr form, sie form ("... Sie"). If missing, shows em dash "—".
     */
    fun buildMasterVerbRows(verbs: List<com.example.data.model.VerbConjugationResult>): List<VerbMasterRow> {
        val seen = mutableSetOf<String>()
        val result = mutableListOf<VerbMasterRow>()

        for (v in verbs) {
            val key = v.word.trim().lowercase(java.util.Locale.GERMAN)
            if (key.isEmpty() || !seen.add(key)) continue

            val inf = v.infinitiv.ifBlank { v.word }

            fun cleanPronoun(raw: String, pronoun: String): String {
                val t = raw.trim()
                if (t.isBlank() || t == "-") return "–"
                if (t.startsWith("$pronoun ", ignoreCase = true)) {
                    val sub = t.substring(pronoun.length + 1).trim()
                    return if (sub.isBlank()) "–" else sub
                }
                return t
            }

            fun getTenseRow(tenseKey: String, tenseNameDe: String): VerbMasterRow {
                val t = v.tenses.firstOrNull { it.tenseKey.equals(tenseKey, ignoreCase = true) }
                return VerbMasterRow(
                    infinitiv = inf,
                    zeit = tenseNameDe,
                    ich = cleanPronoun(t?.ich.orEmpty(), "ich"),
                    du = cleanPronoun(t?.du.orEmpty(), "du"),
                    erSieEs = cleanPronoun(t?.erSieEs.orEmpty(), "er/sie/es").let {
                        if (it == "–" && t?.erSieEs?.isNotBlank() == true) t.erSieEs.trim() else it
                    },
                    wir = cleanPronoun(t?.wir.orEmpty(), "wir"),
                    ihr = cleanPronoun(t?.ihr.orEmpty(), "ihr"),
                    sieSie = cleanPronoun(t?.sieSie.orEmpty(), "sie/Sie").let {
                        if (it == "–" && t?.sieSie?.isNotBlank() == true) t.sieSie.trim() else it
                    }
                )
            }

            result.add(getTenseRow("praesens", "Präsens"))
            result.add(getTenseRow("praeteritum", "Präteritum"))
            result.add(getTenseRow("perfekt", "Perfekt"))
            result.add(getTenseRow("plusquamperfekt", "Plusquamperfekt"))
            result.add(getTenseRow("futur1", "Futur I"))
            result.add(getTenseRow("futur2", "Futur II"))

            val rawDu = v.imperativ.du.trim()
            val rawIhr = v.imperativ.ihr.trim()
            val rawSie = v.imperativ.sie.trim()

            val isMissing = (rawDu.isBlank() || rawDu == "-") &&
                            (rawIhr.isBlank() || rawIhr == "-") &&
                            (rawSie.isBlank() || rawSie == "-")

            val cleanDu = if (rawDu.isBlank() || rawDu == "-") "—" else rawDu
            val cleanIhr = if (rawIhr.isBlank() || rawIhr == "-") "—" else rawIhr
            val cleanSie = when {
                rawSie.isBlank() || rawSie == "-" -> "—"
                rawSie.contains("Sie", ignoreCase = true) -> rawSie
                else -> "$rawSie Sie"
            }

            result.add(
                VerbMasterRow(
                    infinitiv = inf,
                    zeit = "Imperativ",
                    ich = "—",
                    du = if (isMissing) "—" else cleanDu,
                    erSieEs = "—",
                    wir = "—",
                    ihr = if (isMissing) "—" else cleanIhr,
                    sieSie = if (isMissing) "—" else cleanSie,
                    isLastRowOfVerb = true
                )
            )
        }
        return result
    }

    fun buildDeduplicatedVerbRows(verbs: List<com.example.data.model.VerbConjugationResult>): List<VerbExportRow> {
        val seen = mutableSetOf<String>()
        val result = mutableListOf<VerbExportRow>()

        for (v in verbs) {
            val key = v.word.trim().lowercase(java.util.Locale.GERMAN)
            if (key.isEmpty() || !seen.add(key)) continue

            fun formatTense(tenseKey: String): String {
                val t = v.tenses.firstOrNull { it.tenseKey == tenseKey } ?: return "-"
                return "ich ${t.ich}, du ${t.du}, er ${t.erSieEs}, wir ${t.wir}, ihr ${t.ihr}, sie ${t.sieSie}"
            }

            val imperativ = "du ${v.imperativ.du} / ihr ${v.imperativ.ihr} / Sie ${v.imperativ.sie}".trim(' ', '/')

            result.add(
                VerbExportRow(
                    infinitiv = v.infinitiv.ifBlank { v.word },
                    hilfsverb = v.hilfsverb,
                    partizip1 = v.partizip1,
                    partizip2 = v.partizip2,
                    englishTranslation = cleanEnglishTranslation(v.meaningEnglish),
                    praesens = formatTense("praesens"),
                    praeteritum = formatTense("praeteritum"),
                    perfekt = formatTense("perfekt"),
                    plusquamperfekt = formatTense("plusquamperfekt"),
                    futur1 = formatTense("futur1"),
                    futur2 = formatTense("futur2"),
                    imperativ = imperativ.ifBlank { "-" }
                )
            )
        }
        return result
    }

    /**
     * Deduplicates the input words by base noun (case-insensitive) and maps each word
     * to a single continuous horizontal row conforming to the 8 required columns (no Ablativ).
     * Order preserved by first search time (oldest first).
     */
    fun buildDeduplicatedRows(words: List<WordDeclensionResult>): List<WordExportRow> {
        val seen = mutableSetOf<String>()
        val result = mutableListOf<WordExportRow>()

        for (w in words) {
            val normalizedKey = w.word.trim().lowercase(java.util.Locale.GERMAN)
            if (normalizedKey.isEmpty() || !seen.add(normalizedKey)) {
                continue // Skip duplicates to ensure each searched word appears exactly once
            }

            // Nomen (Singular) with article, e.g. "das Schloss", "der Aufzug"
            val nomenSingular = "${w.genderArticle} ${w.word}".trim()

            // Plural full form, e.g. "die Schlösser", "die Aufzüge"
            val pluralForm = if (w.pluralNoun.isNotBlank()) {
                w.pluralNoun
            } else {
                val nomPlural = w.plural.rows.firstOrNull { it.caseKey == "nominativ" }?.definite
                if (!nomPlural.isNullOrBlank()) nomPlural else "die ${w.word}"
            }

            // English translation: remove any Arabic characters to strictly guarantee German/English only
            val translation = cleanEnglishTranslation(w.meaningEnglish)

            // Helper to format: "Singular / Plural" (using definite forms or explicit values)
            fun formatCase(caseKey: String): String {
                val singRow = w.singular.rows.firstOrNull { it.caseKey == caseKey }
                val plurRow = w.plural.rows.firstOrNull { it.caseKey == caseKey }

                val singDef = singRow?.definite?.trim().orEmpty()
                val plurDef = plurRow?.definite?.trim().orEmpty()

                return when {
                    singDef.isNotEmpty() && plurDef.isNotEmpty() -> "$singDef / $plurDef"
                    singDef.isNotEmpty() -> singDef
                    plurDef.isNotEmpty() -> "- / $plurDef"
                    else -> "-"
                }
            }

            val nominativ = formatCase("nominativ")
            val akkusativ = formatCase("akkusativ")
            val genitiv = formatCase("genitiv")
            val dativ = formatCase("dativ")

            // Normalized German Genus (Maskulin, Feminin, Neutrum)
            val genus = when (w.gender.trim().lowercase(java.util.Locale.GERMAN)) {
                "maskulin", "m", "masculine", "der" -> "Maskulin"
                "feminin", "f", "feminine", "die" -> "Feminin"
                "neutrum", "n", "neuter", "das" -> "Neutrum"
                else -> when (w.genderArticle.trim().lowercase(java.util.Locale.GERMAN)) {
                    "der" -> "Maskulin"
                    "die" -> "Feminin"
                    "das" -> "Neutrum"
                    else -> w.gender.trim().ifBlank { "-" }
                }
            }

            result.add(
                WordExportRow(
                    nomenSingular = nomenSingular,
                    plural = pluralForm,
                    englishTranslation = translation,
                    nominativ = nominativ,
                    akkusativ = akkusativ,
                    genitiv = genitiv,
                    dativ = dativ,
                    genus = genus
                )
            )
        }

        return result
    }

    private fun cleanEnglishTranslation(raw: String): String {
        // Strip Arabic script characters to enforce German & English only
        val noArabic = raw.replace(Regex("[\\u0600-\\u06FF\\u0750-\\u077F\\u08A0-\\u08FF\\uFB50-\\uFDFF\\uFE70-\\uFEFF]"), "").trim()
        return noArabic.trim(' ', ',', '/', '-')
    }

    /**
     * Generates a genuine native Microsoft Excel (.xlsx) OpenXML zip archive.
     * Features:
     * - Header background #D9D9D9 with bold 11pt black font and left alignment.
     * - Alternating zebra data rows: Row 1 #FFFFFF, Row 2 #F2F2F2, font 10pt regular, left-aligned.
     * - Thin 0.5pt gray gridlines between all cells.
     * - No text wrapping: all content remains strictly single-line.
     * - 8 columns: Nomen (Singular), Plural, English translation, Nominativ, Akkusativ, Genitiv, Dativ, Genus.
     * - Auto-filter enabled across all 8 columns.
     */
    fun createXlsxFile(
        file: File,
        words: List<WordDeclensionResult>,
        documentTitle: String = "Suchverlauf_Deutsch"
    ) {
        val rows = buildDeduplicatedRows(words)
        val cleanTitle = documentTitle.trim().trimStart('.', '_', ' ').ifBlank { "Suchverlauf_Deutsch" }

        ZipOutputStream(FileOutputStream(file)).use { zos ->
            // [Content_Types].xml
            addZipEntry(
                zos,
                "[Content_Types].xml",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
</Types>"""
            )

            // _rels/.rels
            addZipEntry(
                zos,
                "_rels/.rels",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""
            )

            // docProps/core.xml
            addZipEntry(
                zos,
                "docProps/core.xml",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
  xmlns:dc="http://purl.org/dc/elements/1.1/"
  xmlns:dcterms="http://purl.org/dc/terms/"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:title>${escapeXml(cleanTitle)}</dc:title>
  <dc:creator>Deklination &amp; Konjugation App</dc:creator>
</cp:coreProperties>"""
            )

            // docProps/app.xml
            addZipEntry(
                zos,
                "docProps/app.xml",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">
  <Application>Deklination &amp; Konjugation Android</Application>
</Properties>"""
            )

            // xl/_rels/workbook.xml.rels
            addZipEntry(
                zos,
                "xl/_rels/workbook.xml.rels",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""
            )

            // xl/workbook.xml
            addZipEntry(
                zos,
                "xl/workbook.xml",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
  xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="${escapeXml(safeSheetName(cleanTitle))}" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>"""
            )

            // xl/styles.xml
            addZipEntry(zos, "xl/styles.xml", getStandardStylesXml())

            // xl/worksheets/sheet1.xml
            val sheetXml = buildWorksheetXml(HEADERS, rows.map { it.toList() }, cleanTitle)
            addZipEntry(zos, "xl/worksheets/sheet1.xml", sheetXml)
        }
    }

    /**
     * Sanitizes a string for use as an Excel worksheet name (max 31 chars, no illegal characters).
     */
    fun safeSheetName(rawName: String, fallback: String = "Suchverlauf"): String {
        val cleaned = rawName
            .replace(Regex("""[\\/?*\[\]:]"""), "_")
            .trim(' ', '_', '\t', '\n', '\r', '.')
        val truncated = if (cleaned.length > 31) cleaned.substring(0, 31).trimEnd('_', '.') else cleaned
        return if (truncated.isBlank()) fallback else truncated
    }

    /**
     * Generates an Excel workbook containing Nouns, Verbs, or both (multi-sheet: "Nomen" & "Verben").
     */
    fun createUnifiedXlsxFile(
        file: File,
        nouns: List<WordDeclensionResult>,
        verbs: List<com.example.data.model.VerbConjugationResult>,
        scope: ExportScope,
        documentTitle: String = "Suchverlauf_Deutsch"
    ) {
        val cleanTitle = documentTitle.trim().trimStart('.', '_', ' ').ifBlank { "Suchverlauf_Deutsch" }

        if (scope == ExportScope.NOMEN) {
            createXlsxFile(file, nouns, cleanTitle)
            return
        }

        val nounRows = if (scope != ExportScope.VERB) buildDeduplicatedRows(nouns) else emptyList()
        val verbRows = if (scope != ExportScope.NOMEN) buildMasterVerbRows(verbs) else emptyList()

        if (scope == ExportScope.VERB) {
            // Single sheet for Verbs (Master Table: 8 columns)
            val rowCount = verbRows.size + 1
            val dimensionRef = "A1:H${maxOf(rowCount, 2)}"
            val colLetters = (0 until 8).map { getColLetter(it) }

            ZipOutputStream(FileOutputStream(file)).use { zos ->
                addZipEntry(zos, "[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
</Types>""")

                addZipEntry(zos, "_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>""")

                addZipEntry(zos, "docProps/core.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
  xmlns:dc="http://purl.org/dc/elements/1.1/"
  xmlns:dcterms="http://purl.org/dc/terms/"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:title>${escapeXml(cleanTitle)}</dc:title>
  <dc:creator>Deklination &amp; Konjugation App</dc:creator>
</cp:coreProperties>""")

                addZipEntry(zos, "docProps/app.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">
  <Application>Deklination &amp; Konjugation Android</Application>
</Properties>""")

                addZipEntry(zos, "xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>""")

                addZipEntry(zos, "xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
  xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="${escapeXml(safeSheetName(cleanTitle))}" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>""")

                addZipEntry(zos, "xl/styles.xml", getStandardStylesXml())

                val sheetContent = buildWorksheetXml(VERB_MASTER_HEADERS, verbRows.map { it.toList() }, cleanTitle)
                addZipEntry(zos, "xl/worksheets/sheet1.xml", sheetContent)
            }
            return
        }

        // Scope == ALLE: Multi-sheet (Sheet 1: Nomen, Sheet 2: Verben)
        ZipOutputStream(FileOutputStream(file)).use { zos ->
            addZipEntry(zos, "[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
</Types>""")

            addZipEntry(zos, "_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>""")

            addZipEntry(zos, "docProps/core.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
  xmlns:dc="http://purl.org/dc/elements/1.1/"
  xmlns:dcterms="http://purl.org/dc/terms/"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:title>${escapeXml(cleanTitle)}</dc:title>
  <dc:creator>Deklination &amp; Konjugation App</dc:creator>
</cp:coreProperties>""")

            addZipEntry(zos, "docProps/app.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">
  <Application>Deklination &amp; Konjugation Android</Application>
</Properties>""")

            addZipEntry(zos, "xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>""")

            val sheet1Name = safeSheetName("${cleanTitle}_Nomen", "Nomen")
            val sheet2Name = safeSheetName("${cleanTitle}_Verben", "Verben")

            addZipEntry(zos, "xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
  xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="${escapeXml(sheet1Name)}" sheetId="1" r:id="rId1"/>
    <sheet name="${escapeXml(sheet2Name)}" sheetId="2" r:id="rId2"/>
  </sheets>
</workbook>""")

            addZipEntry(zos, "xl/styles.xml", getStandardStylesXml())

            // Sheet 1: Nomen
            val sheet1Xml = buildWorksheetXml(HEADERS, nounRows.map { it.toList() }, cleanTitle)
            addZipEntry(zos, "xl/worksheets/sheet1.xml", sheet1Xml)

            // Sheet 2: Verben
            val sheet2Xml = buildWorksheetXml(VERB_MASTER_HEADERS, verbRows.map { it.toList() }, cleanTitle)
            addZipEntry(zos, "xl/worksheets/sheet2.xml", sheet2Xml)
        }
    }

    private fun getColLetter(index: Int): String {
        var temp = index
        val sb = StringBuilder()
        while (temp >= 0) {
            sb.append(('A'.code + (temp % 26)).toChar())
            temp = temp / 26 - 1
        }
        return sb.reverse().toString()
    }

    private fun getStandardStylesXml(): String {
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="3">
    <font>
      <sz val="10"/>
      <color rgb="FF0F172A"/>
      <name val="Calibri"/>
    </font>
    <font>
      <b/>
      <sz val="11"/>
      <color rgb="FF0F172A"/>
      <name val="Calibri"/>
    </font>
    <font>
      <b/>
      <sz val="14"/>
      <color rgb="FF0F172A"/>
      <name val="Calibri"/>
    </font>
  </fonts>
  <fills count="4">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill>
      <patternFill patternType="solid">
        <fgColor rgb="FFD9D9D9"/>
      </patternFill>
    </fill>
    <fill>
      <patternFill patternType="solid">
        <fgColor rgb="FFF2F2F2"/>
      </patternFill>
    </fill>
  </fills>
  <borders count="3">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border>
      <left style="thin"><color rgb="FFD0D0D0"/></left>
      <right style="thin"><color rgb="FFD0D0D0"/></right>
      <top style="thin"><color rgb="FFD0D0D0"/></top>
      <bottom style="thin"><color rgb="FFD0D0D0"/></bottom>
    </border>
    <border>
      <left style="thin"><color rgb="FFB0B0B0"/></left>
      <right style="thin"><color rgb="FFB0B0B0"/></right>
      <top style="thin"><color rgb="FFB0B0B0"/></top>
      <bottom style="medium"><color rgb="FF505050"/></bottom>
    </border>
  </borders>
  <cellStyleXfs count="1">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
  </cellStyleXfs>
  <cellXfs count="5">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="left" vertical="center" wrapText="0"/>
    </xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="left" vertical="center" wrapText="0"/>
    </xf>
    <xf numFmtId="0" fontId="0" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="left" vertical="center" wrapText="0"/>
    </xf>
    <!-- 4: Title Left (s=4) -->
    <xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">
      <alignment horizontal="left" vertical="center" wrapText="0"/>
    </xf>
  </cellXfs>
</styleSheet>"""
    }

    private fun buildWorksheetXml(
        headers: List<String>,
        rows: List<List<String>>,
        documentTitle: String
    ): String {
        val colCount = headers.size
        val rowCount = rows.size + 2 // Row 1 = Title, Row 2 = Header, Row 3..N = Data
        val lastColLetter = getColLetter(colCount - 1)
        val dimensionRef = "A1:${lastColLetter}${maxOf(rowCount, 3)}"

        val colWidths = DoubleArray(colCount) { 16.0 }
        headers.forEachIndexed { i, h ->
            colWidths[i] = maxOf(colWidths[i], h.length * 1.25)
        }
        for (r in rows) {
            for (i in 0 until minOf(colCount, r.size)) {
                colWidths[i] = maxOf(colWidths[i], r[i].length * 1.15)
            }
        }
        for (i in 0 until colCount) {
            colWidths[i] = colWidths[i].coerceIn(14.0, 55.0)
        }

        val sheetBuilder = StringBuilder()
        sheetBuilder.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <dimension ref="$dimensionRef"/>
  <sheetViews>
    <sheetView tabSelected="1" workbookViewId="0">
      <pane ySplit="2" topLeftCell="A3" activePane="bottomLeft" state="frozen"/>
    </sheetView>
  </sheetViews>
  <sheetFormatPr defaultRowHeight="20" customHeight="1"/>
  <cols>
""")
        for (i in 0 until colCount) {
            val colIndex = i + 1
            val widthFormatted = String.format(java.util.Locale.US, "%.1f", colWidths[i])
            sheetBuilder.append("""    <col min="$colIndex" max="$colIndex" width="$widthFormatted" customWidth="1"/>
""")
        }
        sheetBuilder.append("""  </cols>
  <sheetData>
""")

        // Row 1: Document Title in top-left cell A1 (14pt bold, height 28)
        sheetBuilder.append("""    <row r="1" ht="28" customHeight="1">
      <c r="A1" s="4" t="inlineStr"><is><t>${escapeXml(documentTitle)}</t></is></c>
    </row>
""")

        // Row 2: Header Row (11pt bold, #D9D9D9 fill, border, height 26)
        sheetBuilder.append("""    <row r="2" ht="26" customHeight="1">
""")
        headers.forEachIndexed { i, h ->
            val cellRef = "${getColLetter(i)}2"
            sheetBuilder.append("""      <c r="$cellRef" s="1" t="inlineStr"><is><t>${escapeXml(h)}</t></is></c>
""")
        }
        sheetBuilder.append("""    </row>
""")

        // Rows 3+: Data Rows
        rows.forEachIndexed { rowIndex, rowData ->
            val rNum = rowIndex + 3
            val isZebra = rowIndex % 2 == 1
            val styleId = if (isZebra) 3 else 2

            sheetBuilder.append("""    <row r="$rNum" ht="22" customHeight="1">
""")
            for (cIndex in 0 until minOf(colCount, rowData.size)) {
                val cellRef = "${getColLetter(cIndex)}$rNum"
                val textVal = escapeXml(rowData[cIndex])
                sheetBuilder.append("""      <c r="$cellRef" s="$styleId" t="inlineStr"><is><t>$textVal</t></is></c>
""")
            }
            sheetBuilder.append("""    </row>
""")
        }

        sheetBuilder.append("""  </sheetData>
  <autoFilter ref="A2:${lastColLetter}${maxOf(rows.size + 2, 2)}"/>
</worksheet>""")

        return sheetBuilder.toString()
    }

    /**
     * Generates landscape PDF for Nouns conforming to PaperSizeOption.
     */
    fun createPdfFile(
        file: File,
        words: List<WordDeclensionResult>,
        documentTitle: String = "Suchverlauf_Deutsch",
        paperSize: PaperSizeOption = PaperSizeOption.DEFAULT
    ) {
        createUnifiedPdfFile(
            file = file,
            nouns = words,
            verbs = emptyList(),
            scope = ExportScope.NOMEN,
            documentTitle = documentTitle,
            paperSize = paperSize
        )
    }

    /**
     * Generates unified PDF with Nouns, Verbs, or both, formatted according to PaperSizeOption.
     * When exporting Verbs, generates ONE unified master table with 8 columns:
     * Verb (Infinitiv) | Zeit (Tense) | ich | du | er/sie/es | wir | ihr | sie/Sie
     * - 7 rows per verb (6 tenses + Imperativ)
     * - Deduplicated, ordered chronologically by first search timestamp
     * - Fixed table header repeating at top of every page
     * - Font size dynamically scales to ensure all columns fit on selected paper size
     */
    fun createUnifiedPdfFile(
        file: File,
        nouns: List<WordDeclensionResult>,
        verbs: List<com.example.data.model.VerbConjugationResult>,
        scope: ExportScope,
        documentTitle: String = "Suchverlauf_Deutsch",
        paperSize: PaperSizeOption = PaperSizeOption.DEFAULT
    ) {
        val cleanTitle = documentTitle.trim().trimStart('.', '_', ' ').ifBlank { "Suchverlauf_Deutsch" }
        val doc = PdfDocument()

        val pageWidth = paperSize.widthPt
        val pageHeight = paperSize.heightPt
        val margin = if (pageWidth <= 500) 18f else 24f
        val contentWidth = pageWidth - (margin * 2)

        val headerPaint = Paint().apply {
            color = Color.rgb(217, 217, 217) // #D9D9D9
            isAntiAlias = true
            style = Paint.Style.FILL
        }

        val headerBottomBorderPaint = Paint().apply {
            color = Color.rgb(80, 80, 80)
            strokeWidth = 1.5f
            style = Paint.Style.STROKE
            isAntiAlias = true
        }

        val gridBorderPaint = Paint().apply {
            color = Color.rgb(215, 220, 228)
            strokeWidth = 0.5f
            style = Paint.Style.STROKE
            isAntiAlias = true
        }

        val verbGroupDividerPaint = Paint().apply {
            color = Color.rgb(100, 116, 139)
            strokeWidth = 1.2f
            style = Paint.Style.STROKE
            isAntiAlias = true
        }

        val zebraLightPaint = Paint().apply {
            color = Color.rgb(248, 249, 251)
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val titlePaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = if (paperSize.isLandscape) 14f else 13f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val subtitlePaint = Paint().apply {
            color = Color.rgb(100, 116, 139)
            textSize = 8f
            isAntiAlias = true
        }

        var pageNumber = 1

        // 1. Render Nouns first if scope is ALLE or NOMEN
        if ((scope == ExportScope.ALLE || scope == ExportScope.NOMEN) && (nouns.isNotEmpty() || scope == ExportScope.NOMEN)) {
            val nounRows = buildDeduplicatedRows(nouns)
            var currentNounIdx = 0

            // Dynamic scaling for Nouns based on paper size
            var nounFontSize = paperSize.defaultFontSizePt
            val nounCellPaint = Paint().apply {
                color = Color.rgb(15, 23, 42)
                textSize = nounFontSize
                isAntiAlias = true
            }
            val nounBoldCellPaint = Paint().apply {
                color = Color.rgb(15, 23, 42)
                textSize = nounFontSize
                isFakeBoldText = true
                isAntiAlias = true
            }
            val nounHeaderFontSize = maxOf(nounFontSize + 0.5f, paperSize.headerFontSizePt.coerceAtMost(nounFontSize + 1.5f))
            val nounHeaderTextPaint = Paint().apply {
                color = Color.rgb(15, 23, 42)
                textSize = nounHeaderFontSize
                isFakeBoldText = true
                isAntiAlias = true
            }

            val nounRowHeight = maxOf(nounFontSize * 1.85f, 16f)
            val nounHeaderHeight = maxOf(nounHeaderFontSize * 2.1f, 20f)

            val nounRatios = floatArrayOf(0.15f, 0.15f, 0.14f, 0.12f, 0.12f, 0.12f, 0.12f, 0.08f)
            val nounColWidths = FloatArray(8)
            for (i in 0 until 7) {
                nounColWidths[i] = (contentWidth * nounRatios[i]).toInt().toFloat()
            }
            nounColWidths[7] = contentWidth - (0 until 7).sumOf { nounColWidths[it].toDouble() }.toFloat()

            // Dynamic font scale down if any value overflows
            fun nounOverflows(): Boolean {
                for (r in nounRows) {
                    val list = r.toList()
                    for (i in 0 until 8) {
                        if (nounCellPaint.measureText(list[i]) > nounColWidths[i] - 5f) return true
                    }
                }
                return false
            }
            while (nounOverflows() && nounFontSize > 5.5f) {
                nounFontSize -= 0.5f
                nounCellPaint.textSize = nounFontSize
                nounBoldCellPaint.textSize = nounFontSize
            }

            var nounPageCount = 0
            while (currentNounIdx < nounRows.size || (nounRows.isEmpty() && nounPageCount == 0)) {
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                val page = doc.startPage(pageInfo)
                val canvas = page.canvas

                var currentY = margin + 12f
                val nounSectionTitle = when {
                    scope == ExportScope.ALLE && nounPageCount == 0 -> "$cleanTitle — Nomen"
                    scope == ExportScope.ALLE -> "$cleanTitle — Nomen (Fortsetzung)"
                    nounPageCount == 0 -> cleanTitle
                    else -> "$cleanTitle (Fortsetzung)"
                }
                canvas.drawText(nounSectionTitle, margin, currentY, titlePaint)
                currentY += 12f

                // Table Header Bar
                canvas.drawRect(margin, currentY, margin + contentWidth, currentY + nounHeaderHeight, headerPaint)
                var colX = margin
                HEADERS.forEachIndexed { i, h ->
                    val w = nounColWidths[i]
                    canvas.drawText(h, colX + 4f, currentY + (nounHeaderHeight * 0.68f), nounHeaderTextPaint)
                    colX += w
                }
                canvas.drawLine(margin, currentY + nounHeaderHeight, margin + contentWidth, currentY + nounHeaderHeight, headerBottomBorderPaint)
                currentY += nounHeaderHeight

                if (nounRows.isEmpty()) {
                    canvas.drawText("Keine Nomen im Suchverlauf vorhanden.", margin + 6f, currentY + 14f, subtitlePaint)
                } else {
                    while (currentNounIdx < nounRows.size) {
                        if (currentY + nounRowHeight > pageHeight - margin - 18f) break
                        val r = nounRows[currentNounIdx]
                        if (currentNounIdx % 2 == 1) {
                            canvas.drawRect(margin, currentY, margin + contentWidth, currentY + nounRowHeight, zebraLightPaint)
                        }
                        val values = r.toList()
                        var cellX = margin
                        values.forEachIndexed { i, txt ->
                            val p = if (i == 0 || i == 1) nounBoldCellPaint else nounCellPaint
                            var t = txt
                            while (t.isNotEmpty() && p.measureText(t) > (nounColWidths[i] - 5f)) {
                                t = t.dropLast(1)
                            }
                            if (t.length < txt.length && t.length > 2) {
                                t = t.dropLast(1) + "…"
                            }
                            canvas.drawText(t, cellX + 4f, currentY + (nounRowHeight * 0.72f), p)
                            cellX += nounColWidths[i]
                        }
                        canvas.drawLine(margin, currentY + nounRowHeight, margin + contentWidth, currentY + nounRowHeight, gridBorderPaint)
                        currentY += nounRowHeight
                        currentNounIdx++
                    }
                }

                val footerText = if (scope == ExportScope.ALLE) "Seite $pageNumber — Nomen" else "Seite $pageNumber"
                canvas.drawText(footerText, pageWidth - margin - subtitlePaint.measureText(footerText), pageHeight - 10f, subtitlePaint)

                doc.finishPage(page)
                pageNumber++
                nounPageCount++
                if (currentNounIdx >= nounRows.size) break
            }
        }

        // 2. Render Verbs (Master Table: ONE single table for all verbs)
        if ((scope == ExportScope.ALLE || scope == ExportScope.VERB) && (verbs.isNotEmpty() || scope == ExportScope.VERB)) {
            val verbRows = buildMasterVerbRows(verbs)
            var currentVerbIdx = 0

            // 8 fixed columns:
            // Verb (Infinitiv) | Zeit (Tense) | ich | du | er/sie/es | wir | ihr | sie/Sie
            val verbRatios = floatArrayOf(0.13f, 0.13f, 0.12f, 0.12f, 0.125f, 0.125f, 0.12f, 0.15f)
            val verbColWidths = FloatArray(8)
            for (i in 0 until 7) {
                verbColWidths[i] = (contentWidth * verbRatios[i]).toInt().toFloat()
            }
            verbColWidths[7] = contentWidth - (0 until 7).sumOf { verbColWidths[it].toDouble() }.toFloat()

            // Dynamic font sizing based on selected paper size and column widths
            var effectiveFontSize = paperSize.defaultFontSizePt
            val verbCellPaint = Paint().apply {
                color = Color.rgb(15, 23, 42)
                textSize = effectiveFontSize
                isAntiAlias = true
            }
            val verbBoldCellPaint = Paint().apply {
                color = Color.rgb(15, 23, 42)
                textSize = effectiveFontSize
                isFakeBoldText = true
                isAntiAlias = true
            }

            fun anyVerbCellOverflows(): Boolean {
                for (r in verbRows) {
                    val list = r.toList()
                    for (i in 0 until 8) {
                        val p = if (i == 0) verbBoldCellPaint else verbCellPaint
                        if (p.measureText(list[i]) > verbColWidths[i] - 4.5f) return true
                    }
                }
                return false
            }
            while (anyVerbCellOverflows() && effectiveFontSize > 5.5f) {
                effectiveFontSize -= 0.5f
                verbCellPaint.textSize = effectiveFontSize
                verbBoldCellPaint.textSize = effectiveFontSize
            }

            val headerFontSize = maxOf(effectiveFontSize + 0.5f, paperSize.headerFontSizePt.coerceAtMost(effectiveFontSize + 1.5f))
            val verbHeaderTextPaint = Paint().apply {
                color = Color.rgb(15, 23, 42)
                textSize = headerFontSize
                isFakeBoldText = true
                isAntiAlias = true
            }

            val verbRowHeight = maxOf(effectiveFontSize * 1.85f, 16f)
            val verbHeaderHeight = maxOf(headerFontSize * 2.1f, 20f)

            var verbPageCount = 0
            while (currentVerbIdx < verbRows.size || (verbRows.isEmpty() && verbPageCount == 0)) {
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                val page = doc.startPage(pageInfo)
                val canvas = page.canvas

                var currentY = margin + 12f
                val sectionTitle = when {
                    scope == ExportScope.ALLE && verbPageCount == 0 -> "$cleanTitle — Verben"
                    scope == ExportScope.ALLE -> "$cleanTitle — Verben (Fortsetzung)"
                    verbPageCount == 0 -> cleanTitle
                    else -> "$cleanTitle (Fortsetzung)"
                }
                canvas.drawText(sectionTitle, margin, currentY, titlePaint)
                currentY += 12f

                // Fixed table header (repeating at top of every page)
                canvas.drawRect(margin, currentY, margin + contentWidth, currentY + verbHeaderHeight, headerPaint)
                var colX = margin
                VERB_MASTER_HEADERS.forEachIndexed { i, h ->
                    val w = verbColWidths[i]
                    canvas.drawText(h, colX + 4f, currentY + (verbHeaderHeight * 0.68f), verbHeaderTextPaint)
                    colX += w
                }
                canvas.drawLine(margin, currentY + verbHeaderHeight, margin + contentWidth, currentY + verbHeaderHeight, headerBottomBorderPaint)
                currentY += verbHeaderHeight

                if (verbRows.isEmpty()) {
                    canvas.drawText("Keine Verben im Suchverlauf vorhanden.", margin + 6f, currentY + 14f, subtitlePaint)
                } else {
                    while (currentVerbIdx < verbRows.size) {
                        if (currentY + verbRowHeight > pageHeight - margin - 18f) break
                        val r = verbRows[currentVerbIdx]
                        if (currentVerbIdx % 2 == 1) {
                            canvas.drawRect(margin, currentY, margin + contentWidth, currentY + verbRowHeight, zebraLightPaint)
                        }
                        val values = r.toList()
                        var cellX = margin
                        values.forEachIndexed { i, txt ->
                            val p = if (i == 0) verbBoldCellPaint else verbCellPaint
                            var t = txt
                            while (t.isNotEmpty() && p.measureText(t) > (verbColWidths[i] - 4.5f)) {
                                t = t.dropLast(1)
                            }
                            if (t.length < txt.length && t.length > 2) {
                                t = t.dropLast(1) + "…"
                            }
                            canvas.drawText(t, cellX + 4f, currentY + (verbRowHeight * 0.72f), p)
                            cellX += verbColWidths[i]
                        }

                        // Cell border
                        if (r.isLastRowOfVerb) {
                            // Distinct divider between different verbs
                            canvas.drawLine(margin, currentY + verbRowHeight, margin + contentWidth, currentY + verbRowHeight, verbGroupDividerPaint)
                        } else {
                            canvas.drawLine(margin, currentY + verbRowHeight, margin + contentWidth, currentY + verbRowHeight, gridBorderPaint)
                        }

                        currentY += verbRowHeight
                        currentVerbIdx++
                    }
                }

                val footerText = if (scope == ExportScope.ALLE) "Seite $pageNumber — Verben" else "Seite $pageNumber"
                canvas.drawText(footerText, pageWidth - margin - subtitlePaint.measureText(footerText), pageHeight - 10f, subtitlePaint)

                doc.finishPage(page)
                pageNumber++
                verbPageCount++
                if (currentVerbIdx >= verbRows.size) break
            }
        }

        FileOutputStream(file).use { fos ->
            doc.writeTo(fos)
        }
        doc.close()
    }

    /**
     * Renders responsive HTML in Landscape orientation for direct printing or saving via Android PrintManager.
     */
    fun generateLandscapePrintableHtml(
        words: List<WordDeclensionResult>,
        documentTitle: String = "Suchverlauf_Deutsch"
    ): String {
        val rows = buildDeduplicatedRows(words)
        val cleanTitle = documentTitle.trim().trimStart('.', '_', ' ').ifBlank { "Suchverlauf_Deutsch" }
        val sb = StringBuilder()

        sb.append("""
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>${escapeXml(cleanTitle)}</title>
    <style>
        @page {
            size: A4 landscape;
            margin: 8mm 8mm 8mm 8mm;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            margin: 10px;
            color: #0F172A;
            background: #FFFFFF;
            font-size: 10px;
            line-height: 1.2;
        }
        h1 {
            font-size: 15px;
            color: #0F172A;
            margin: 0 0 3px 0;
            font-weight: bold;
        }
        p.subtitle {
            font-size: 10px;
            color: #64748B;
            margin: 0 0 12px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 16px;
        }
        tr {
            page-break-inside: avoid;
        }
        thead {
            display: table-header-group;
        }
        th {
            background-color: #D9D9D9 !important;
            color: #0F172A !important;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
            text-align: left;
            padding: 6px 5px;
            font-size: 11px;
            font-weight: bold;
            border: 0.5px solid #D0D0D0;
            border-bottom: 1.5px solid #505050;
            white-space: nowrap;
        }
        td {
            padding: 5px 5px;
            border: 0.5px solid #D0D0D0;
            font-size: 10px;
            text-align: left;
            vertical-align: middle;
            white-space: nowrap;
        }
        tr.data-row:nth-child(even) {
            background-color: #F2F2F2 !important;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        .bold-noun {
            font-weight: bold;
            color: #0F172A;
        }
        .translation-col {
            color: #1E293B;
        }
    </style>
</head>
<body>
    <h1>${escapeXml(cleanTitle)}</h1>

    <table>
        <thead>
            <tr>
                <th>Nomen (Singular)</th>
                <th>Plural</th>
                <th>English translation</th>
                <th>Nominativ (Sg./Pl.)</th>
                <th>Akkusativ (Sg./Pl.)</th>
                <th>Genitiv (Sg./Pl.)</th>
                <th>Dativ (Sg./Pl.)</th>
                <th>Genus</th>
            </tr>
        </thead>
        <tbody>
        """.trimIndent())

        for (row in rows) {
            sb.append("""
            <tr class="data-row">
                <td class="bold-noun">${escapeXml(row.nomenSingular)}</td>
                <td class="bold-noun">${escapeXml(row.plural)}</td>
                <td class="translation-col">${escapeXml(row.englishTranslation)}</td>
                <td>${escapeXml(row.nominativ)}</td>
                <td>${escapeXml(row.akkusativ)}</td>
                <td>${escapeXml(row.genitiv)}</td>
                <td>${escapeXml(row.dativ)}</td>
                <td>${escapeXml(row.genus)}</td>
            </tr>
            """.trimIndent())
        }

        sb.append("""
        </tbody>
    </table>
</body>
</html>
        """.trimIndent())

        return sb.toString()
    }

    /**
     * Prints or saves as PDF via Android PrintManager with standard ISO_A4 in LANDSCAPE orientation.
     */
    fun printLandscapeTable(context: Context, words: List<WordDeclensionResult>, jobTitle: String = "Deklination_Suchverlauf") {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val html = generateLandscapePrintableHtml(words, jobTitle)

        val webView = WebView(context)
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                val printAdapter = webView.createPrintDocumentAdapter(jobTitle)
                val printAttributes = PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape())
                    .build()
                printManager.print(jobTitle, printAdapter, printAttributes)
            }
        }
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    /**
     * Generates unified responsive HTML in Landscape orientation for direct printing or saving via Android PrintManager.
     */
    fun generateUnifiedLandscapePrintableHtml(
        nouns: List<WordDeclensionResult>,
        verbs: List<com.example.data.model.VerbConjugationResult>,
        scope: ExportScope,
        documentTitle: String = "Suchverlauf_Deutsch"
    ): String {
        val cleanTitle = documentTitle.trim().trimStart('.', '_', ' ').ifBlank { "Suchverlauf_Deutsch" }
        val sb = StringBuilder()
        sb.append("""
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>${escapeXml(cleanTitle)}</title>
    <style>
        @page {
            size: A4 landscape;
            margin: 8mm 8mm 8mm 8mm;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            margin: 10px;
            color: #0F172A;
            background: #FFFFFF;
            font-size: 10px;
            line-height: 1.2;
        }
        h1 {
            font-size: 15px;
            color: #0F172A;
            margin: 0 0 10px 0;
            font-weight: bold;
        }
        h2 {
            font-size: 13px;
            color: #0F172A;
            margin: 14px 0 6px 0;
            font-weight: bold;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 16px;
        }
        tr {
            page-break-inside: avoid;
        }
        thead {
            display: table-header-group;
        }
        th {
            background-color: #D9D9D9 !important;
            color: #0F172A !important;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
            text-align: left;
            padding: 5px 4px;
            font-size: 10px;
            font-weight: bold;
            border: 0.5px solid #D0D0D0;
            border-bottom: 1.5px solid #505050;
            white-space: nowrap;
        }
        td {
            padding: 4px 4px;
            border: 0.5px solid #D0D0D0;
            font-size: 9.5px;
            text-align: left;
            vertical-align: middle;
            white-space: nowrap;
        }
        tr.data-row:nth-child(even) {
            background-color: #F8F9FB !important;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        tr.verb-divider td {
            border-bottom: 1.5px solid #64748B;
        }
        .bold-cell {
            font-weight: bold;
            color: #0F172A;
        }
    </style>
</head>
<body>
    <h1>${escapeXml(cleanTitle)}</h1>
""".trimIndent())

        if (scope == ExportScope.ALLE || scope == ExportScope.NOMEN) {
            val nounRows = buildDeduplicatedRows(nouns)
            if (scope == ExportScope.ALLE) sb.append("<h2>Nomen</h2>")
            sb.append("""
    <table>
        <thead>
            <tr>
                <th>Nomen (Singular)</th>
                <th>Plural</th>
                <th>English translation</th>
                <th>Nominativ (Sg./Pl.)</th>
                <th>Akkusativ (Sg./Pl.)</th>
                <th>Genitiv (Sg./Pl.)</th>
                <th>Dativ (Sg./Pl.)</th>
                <th>Genus</th>
            </tr>
        </thead>
        <tbody>
""".trimIndent())
            for (r in nounRows) {
                sb.append("""
            <tr class="data-row">
                <td class="bold-cell">${escapeXml(r.nomenSingular)}</td>
                <td class="bold-cell">${escapeXml(r.plural)}</td>
                <td>${escapeXml(r.englishTranslation)}</td>
                <td>${escapeXml(r.nominativ)}</td>
                <td>${escapeXml(r.akkusativ)}</td>
                <td>${escapeXml(r.genitiv)}</td>
                <td>${escapeXml(r.dativ)}</td>
                <td>${escapeXml(r.genus)}</td>
            </tr>
""".trimIndent())
            }
            sb.append("</tbody></table>")
        }

        if (scope == ExportScope.ALLE || scope == ExportScope.VERB) {
            val verbRows = buildMasterVerbRows(verbs)
            if (scope == ExportScope.ALLE) sb.append("<h2>Verben</h2>")
            sb.append("""
    <table>
        <thead>
            <tr>
                <th>Verb (Infinitiv)</th>
                <th>Zeit (Tense)</th>
                <th>ich</th>
                <th>du</th>
                <th>er/sie/es</th>
                <th>wir</th>
                <th>ihr</th>
                <th>sie/Sie</th>
            </tr>
        </thead>
        <tbody>
""".trimIndent())
            for (vr in verbRows) {
                val rowClass = if (vr.isLastRowOfVerb) "data-row verb-divider" else "data-row"
                sb.append("""
            <tr class="$rowClass">
                <td class="bold-cell">${escapeXml(vr.infinitiv)}</td>
                <td>${escapeXml(vr.zeit)}</td>
                <td>${escapeXml(vr.ich)}</td>
                <td>${escapeXml(vr.du)}</td>
                <td>${escapeXml(vr.erSieEs)}</td>
                <td>${escapeXml(vr.wir)}</td>
                <td>${escapeXml(vr.ihr)}</td>
                <td>${escapeXml(vr.sieSie)}</td>
            </tr>
""".trimIndent())
            }
            sb.append("</tbody></table>")
        }

        sb.append("</body></html>")
        return sb.toString()
    }

    /**
     * Unified print via Android PrintManager.
     */
    fun printUnifiedLandscapeTable(
        context: Context,
        nouns: List<WordDeclensionResult>,
        verbs: List<com.example.data.model.VerbConjugationResult>,
        scope: ExportScope,
        jobTitle: String = "Suchverlauf_Deutsch"
    ) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val html = generateUnifiedLandscapePrintableHtml(nouns, verbs, scope, jobTitle)

        val webView = WebView(context)
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                val printAdapter = webView.createPrintDocumentAdapter(jobTitle)
                val printAttributes = PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape())
                    .build()
                printManager.print(jobTitle, printAdapter, printAttributes)
            }
        }
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    /**
     * CSV fallback with UTF-8 BOM, following the exact 8 adjacent columns.
     */
    fun generateCsv(words: List<WordDeclensionResult>): String {
        val rows = buildDeduplicatedRows(words)
        val sb = StringBuilder()
        sb.append("\uFEFF") // UTF-8 BOM

        sb.append(HEADERS.joinToString(",") { escapeCsv(it) }).append("\r\n")

        for (r in rows) {
            sb.append(r.toList().joinToString(",") { escapeCsv(it) }).append("\r\n")
        }

        return sb.toString()
    }

    private fun addZipEntry(zos: ZipOutputStream, path: String, content: String) {
        val entry = ZipEntry(path)
        zos.putNextEntry(entry)
        val bytes = content.toByteArray(StandardCharsets.UTF_8)
        zos.write(bytes, 0, bytes.size)
        zos.closeEntry()
    }

    private fun escapeXml(s: String): String {
        return s.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }

    private fun escapeCsv(v: String): String {
        val containsSpecial = v.contains(",") || v.contains("\"") || v.contains("\n") || v.contains("\r")
        return if (containsSpecial) {
            "\"" + v.replace("\"", "\"\"") + "\""
        } else {
            "\"$v\""
        }
    }
}
