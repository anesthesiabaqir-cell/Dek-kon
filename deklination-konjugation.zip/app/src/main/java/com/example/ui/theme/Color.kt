package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color

// Dynamic Theme Accessors matching the current active theme package
// Automatically adjusts for Light and Dark modes.
val GeoPrimary: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.primary else LocalAppThemePackage.current.primary

val GeoOnPrimary: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.onPrimary else Color.White

val GeoPrimaryContainer: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.primaryContainer else LocalAppThemePackage.current.primaryContainer

val GeoOnPrimaryContainer: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.onPrimaryContainer else LocalAppThemePackage.current.onPrimaryContainer

val GeoSecondary: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.secondary else LocalAppThemePackage.current.secondary

val GeoOnSecondary: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.onSecondary else Color.White

val GeoSecondaryContainer: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.secondaryContainer else LocalAppThemePackage.current.primaryContainer

val GeoOnSecondaryContainer: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.onSecondaryContainer else LocalAppThemePackage.current.onPrimaryContainer

val GeoTertiary: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.tertiary else LocalAppThemePackage.current.accent

val GeoOnTertiary: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.onTertiary else Color.White

val GeoBackground: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.background else LocalAppThemePackage.current.background

val GeoSurface: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.surface else LocalAppThemePackage.current.surface

val GeoSurfaceVariant: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.surfaceVariant else LocalAppThemePackage.current.surfaceVariant

val GeoOnSurface: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.onSurface else LocalAppThemePackage.current.onSurface

val GeoOnSurfaceVariant: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.onSurfaceVariant else LocalAppThemePackage.current.onSurfaceVariant

val GeoBorder: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.outlineVariant else LocalAppThemePackage.current.border

val GeoOutline: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.outline else LocalAppThemePackage.current.outline

val GeoHeaderKasus: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.surfaceVariant else LocalAppThemePackage.current.surfaceVariant

val GeoError: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.error else Color(0xFFBA1A1A)

val GeoOnError: Color
    @Composable
    @ReadOnlyComposable
    get() = if (isSystemInDarkTheme()) MaterialTheme.colorScheme.onError else Color.White

// Static fallback values for non-composable usages if any
val DefaultGeoPrimary = Color(0xFF6A7A7A)
val DefaultGeoBackground = Color(0xFFF5F7F7)
val DefaultGeoSurface = Color(0xFFFFFFFF)

// Gender Accents (consistent grammatical color convention)
val GeoMaskulinText = Color(0xFF1565C0)
val GeoMaskulinBg = Color(0xFFE0F2FE)
val GeoFemininText = Color(0xFFC2185B)
val GeoFemininBg = Color(0xFFFCE7F3)
val GeoNeutrumText = Color(0xFF15803D)
val GeoNeutrumBg = Color(0xFFDCFCE7)
val GeoPluralText = Color(0xFF6B21A8)
val GeoPluralBg = Color(0xFFF3E8FF)
