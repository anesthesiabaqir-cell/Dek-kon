package com.example.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GeoOnSurface
import com.example.ui.theme.GeoOnSurfaceVariant
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoSurfaceVariant
import java.util.Locale
import kotlin.math.round

/**
 * Material 3 Playback Speed Slider for controlling German TTS speech rate.
 *
 * Requirements:
 * - Width: 200dp default, Height: wrap_content (~32dp)
 * - Range: 0.5x to 2.0x, increments of 0.1 (14 steps)
 * - Live Value Display: 12sp, bold, On Surface color, 4dp margin to the right
 * - Dynamic Theming:
 *     Track (Background): Surface Container (GeoSurfaceVariant)
 *     Progress (Active Track): Primary (GeoPrimary)
 *     Thumb (Handle): Primary (GeoPrimary)
 *     Speed Label: On Surface (GeoOnSurface)
 * - Strict Audio Behavior: Dragging never emits audio.
 */
@Composable
fun TtsSpeedSlider(
    speed: Float,
    onSpeedChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    sliderWidth: androidx.compose.ui.unit.Dp = 200.dp
) {
    // Local state ensures fluid visual feedback while dragging
    var sliderValue by remember(speed) { mutableFloatStateOf(speed) }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .wrapContentHeight()
            .testTag("tts_speed_control_container")
    ) {
        Slider(
            value = sliderValue,
            onValueChange = { raw ->
                val snapped = (round(raw * 10f) / 10f).coerceIn(0.5f, 2.0f)
                sliderValue = snapped
                onSpeedChange(snapped)
            },
            valueRange = 0.5f..2.0f,
            steps = 14,
            colors = SliderDefaults.colors(
                thumbColor = GeoPrimary,
                activeTrackColor = GeoPrimary,
                inactiveTrackColor = GeoSurfaceVariant,
                activeTickColor = GeoPrimary.copy(alpha = 0.5f),
                inactiveTickColor = GeoOnSurfaceVariant.copy(alpha = 0.35f)
            ),
            modifier = Modifier
                .width(sliderWidth)
                .wrapContentHeight()
                .testTag("tts_speed_slider")
        )

        Spacer(modifier = Modifier.width(4.dp))

        Text(
            text = String.format(Locale.US, "%.1fx", sliderValue),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = GeoOnSurface,
            modifier = Modifier.testTag("tts_speed_value_label")
        )
    }
}
