package com.example.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.WordDeclensionResult
import com.example.ui.theme.GeoBorder
import com.example.ui.theme.GeoOnSurface
import com.example.ui.theme.GeoOnSurfaceVariant
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceVariant
import com.example.util.ExportSharingManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Modern, compact export dialog:
 * - Small header: [X] Exportieren
 * - Format selector: Excel (.xlsx) / PDF
 * - Single-line file name input field pre-filled with "Suchverlauf_Deutsch"
 * - Two equal-weight action buttons side-by-side:
 *   - [💾 Speichern] -> Opens system save location picker (CreateDocument contract)
 *   - [📤 Teilen] -> Opens Android share sheet directly
 * - Strictly German/English only (no Arabic text, no text wrapping)
 */
@Composable
fun PrintExportDialog(
    currentWord: WordDeclensionResult? = null,
    historyWords: List<WordDeclensionResult> = emptyList(),
    currentGrammarResult: com.example.data.model.GrammarResult? = null,
    nounHistory: List<WordDeclensionResult> = emptyList(),
    verbHistory: List<com.example.data.model.VerbConjugationResult> = emptyList(),
    initialScope: com.example.util.DeclensionHistoryExportHelper.ExportScope = com.example.util.DeclensionHistoryExportHelper.ExportScope.ALLE,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedScope by remember { mutableStateOf(initialScope) }
    var selectedFormat by remember { mutableStateOf(ExportSharingManager.ExportFormat.XLSX) }
    var fileNameInput by remember { mutableStateOf("Suchverlauf_Deutsch") }

    // Paper size selection for PDF (A3, A4, A5, Letter) and orientation (Landscape/Portrait)
    var selectedBaseSize by remember { mutableStateOf("A4") } // "A3", "A4", "A5", "Letter"
    var isLandscape by remember { mutableStateOf(true) }

    val selectedPaperSize = remember(selectedBaseSize, isLandscape) {
        when (selectedBaseSize) {
            "A3" -> if (isLandscape) com.example.util.DeclensionHistoryExportHelper.PaperSizeOption.A3_LANDSCAPE else com.example.util.DeclensionHistoryExportHelper.PaperSizeOption.A3_PORTRAIT
            "A5" -> if (isLandscape) com.example.util.DeclensionHistoryExportHelper.PaperSizeOption.A5_LANDSCAPE else com.example.util.DeclensionHistoryExportHelper.PaperSizeOption.A5_PORTRAIT
            "Letter" -> if (isLandscape) com.example.util.DeclensionHistoryExportHelper.PaperSizeOption.LETTER_LANDSCAPE else com.example.util.DeclensionHistoryExportHelper.PaperSizeOption.LETTER_PORTRAIT
            else -> if (isLandscape) com.example.util.DeclensionHistoryExportHelper.PaperSizeOption.A4_LANDSCAPE else com.example.util.DeclensionHistoryExportHelper.PaperSizeOption.A4_PORTRAIT
        }
    }

    // Resolve Nouns to export
    val effectiveNouns = remember(nounHistory, historyWords, currentWord, currentGrammarResult) {
        if (nounHistory.isNotEmpty()) {
            nounHistory
        } else if (historyWords.isNotEmpty()) {
            historyWords
        } else if (currentGrammarResult is com.example.data.model.GrammarResult.Noun) {
            listOf(currentGrammarResult.declension)
        } else if (currentWord != null) {
            listOf(currentWord)
        } else {
            emptyList()
        }
    }

    // Resolve Verbs to export
    val effectiveVerbs = remember(verbHistory, currentGrammarResult) {
        if (verbHistory.isNotEmpty()) {
            verbHistory
        } else if (currentGrammarResult is com.example.data.model.GrammarResult.Verb) {
            listOf(currentGrammarResult.conjugation)
        } else {
            emptyList()
        }
    }

    // Launcher for creating document at user's chosen folder location
    val saveFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(selectedFormat.mimeType)
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { os ->
                            ExportSharingManager.writeUnifiedToStream(
                                context = context,
                                nouns = effectiveNouns,
                                verbs = effectiveVerbs,
                                scope = selectedScope,
                                format = selectedFormat,
                                outputStream = os,
                                customBaseName = ExportSharingManager.sanitizeFileName(fileNameInput),
                                paperSize = selectedPaperSize
                            )
                        }
                    }
                    Toast.makeText(context, "Datei erfolgreich gespeichert!", Toast.LENGTH_SHORT).show()
                    onDismiss()
                } catch (e: Exception) {
                    Toast.makeText(context, "Fehler: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        BackHandler(enabled = true) {
            onDismiss()
        }

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .testTag("export_dialog_surface"),
            shape = RoundedCornerShape(16.dp),
            color = GeoSurface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Dialog Header: Back button + Title + [X] Close button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("export_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Zurück",
                                tint = GeoOnSurface,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = "Exportieren",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = GeoOnSurface,
                            maxLines = 1
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("dismiss_export_dialog")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Schließen",
                            tint = GeoOnSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Scope Selector: [ Nomen ] [ Verb ] [ Alle ]
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Verlauf:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = GeoOnSurfaceVariant,
                        maxLines = 1
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(GeoSurfaceVariant)
                            .padding(3.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            com.example.util.DeclensionHistoryExportHelper.ExportScope.NOMEN to "Nomen",
                            com.example.util.DeclensionHistoryExportHelper.ExportScope.VERB to "Verb",
                            com.example.util.DeclensionHistoryExportHelper.ExportScope.ALLE to "Alle"
                        ).forEach { (scopeItem, label) ->
                            val isSelected = selectedScope == scopeItem
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(32.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) GeoSurface else Color.Transparent)
                                    .clickable { selectedScope = scopeItem }
                                    .testTag("scope_tab_${scopeItem.name.lowercase()}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (isSelected) GeoOnSurface else GeoOnSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                // Format Selector (Excel vs PDF)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Format:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = GeoOnSurfaceVariant,
                        maxLines = 1
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(GeoSurfaceVariant)
                            .padding(3.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Excel Option
                        val isExcel = selectedFormat == ExportSharingManager.ExportFormat.XLSX
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isExcel) GeoSurface else Color.Transparent)
                                .clickable { selectedFormat = ExportSharingManager.ExportFormat.XLSX }
                                .padding(horizontal = 8.dp)
                                .testTag("format_excel_tab"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TableChart,
                                    contentDescription = null,
                                    tint = if (isExcel) Color(0xFF107C41) else GeoOnSurfaceVariant,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Excel (.xlsx)",
                                    fontSize = 12.sp,
                                    fontWeight = if (isExcel) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (isExcel) GeoOnSurface else GeoOnSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }

                        // PDF Option
                        val isPdf = selectedFormat == ExportSharingManager.ExportFormat.PDF
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isPdf) GeoSurface else Color.Transparent)
                                .clickable { selectedFormat = ExportSharingManager.ExportFormat.PDF }
                                .padding(horizontal = 8.dp)
                                .testTag("format_pdf_tab"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Description,
                                    contentDescription = null,
                                    tint = if (isPdf) Color(0xFFB3261E) else GeoOnSurfaceVariant,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "PDF",
                                    fontSize = 12.sp,
                                    fontWeight = if (isPdf) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (isPdf) GeoOnSurface else GeoOnSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                // Paper Size & Orientation Selector (Visible for PDF format)
                if (selectedFormat == ExportSharingManager.ExportFormat.PDF) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "Papiergröße & Ausrichtung:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = GeoOnSurfaceVariant,
                            maxLines = 1
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(GeoSurfaceVariant)
                                .padding(3.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            listOf("A4", "A3", "A5", "Letter").forEach { sizeLabel ->
                                val isSelected = selectedBaseSize == sizeLabel
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(30.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) GeoSurface else Color.Transparent)
                                        .clickable { selectedBaseSize = sizeLabel }
                                        .testTag("paper_size_${sizeLabel.lowercase()}"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = sizeLabel,
                                        fontSize = 11.5.sp,
                                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                        color = if (isSelected) GeoOnSurface else GeoOnSurfaceVariant,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(GeoSurfaceVariant)
                                .padding(3.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            listOf(true to "Querformat", false to "Hochformat").forEach { (landscape, label) ->
                                val isSelected = isLandscape == landscape
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(30.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) GeoSurface else Color.Transparent)
                                        .clickable { isLandscape = landscape }
                                        .testTag(if (landscape) "paper_landscape" else "paper_portrait"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 11.5.sp,
                                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                        color = if (isSelected) GeoOnSurface else GeoOnSurfaceVariant,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }

                // File Name Input Section
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Dateiname:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = GeoOnSurfaceVariant,
                        maxLines = 1
                    )
                    OutlinedTextField(
                        value = fileNameInput,
                        onValueChange = { input -> fileNameInput = input.trimStart('.') },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("file_name_input"),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Suchverlauf_Deutsch",
                                fontSize = 14.sp,
                                color = GeoOnSurfaceVariant.copy(alpha = 0.6f)
                            )
                        },
                        trailingIcon = {
                            Text(
                                text = ".${selectedFormat.extension}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = GeoOnSurfaceVariant,
                                modifier = Modifier.padding(end = 12.dp)
                            )
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GeoPrimary,
                            unfocusedBorderColor = GeoBorder,
                            focusedContainerColor = GeoSurface,
                            unfocusedContainerColor = GeoSurface
                        )
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Action Buttons Side by Side (Speichern & Teilen) with equal weight
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Save Button
                    Button(
                        onClick = {
                            val sanitizedBase = ExportSharingManager.sanitizeFileName(fileNameInput)
                            val targetFileName = ExportSharingManager.buildFileName(sanitizedBase, selectedFormat)
                            try {
                                saveFileLauncher.launch(targetFileName)
                            } catch (e: Exception) {
                                // Fallback directly to Downloads folder if picker unavailable
                                ExportSharingManager.saveUnifiedToDownloads(
                                    context = context,
                                    nouns = effectiveNouns,
                                    verbs = effectiveVerbs,
                                    scope = selectedScope,
                                    format = selectedFormat,
                                    customBaseName = sanitizedBase,
                                    paperSize = selectedPaperSize
                                )
                                onDismiss()
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("export_save_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GeoPrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Save,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Speichern",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }

                    // Share Button
                    Button(
                        onClick = {
                            val sanitizedBase = ExportSharingManager.sanitizeFileName(fileNameInput)
                            ExportSharingManager.shareUnifiedSearchHistory(
                                context = context,
                                nouns = effectiveNouns,
                                verbs = effectiveVerbs,
                                scope = selectedScope,
                                format = selectedFormat,
                                customBaseName = sanitizedBase,
                                paperSize = selectedPaperSize
                            )
                            onDismiss()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("export_share_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GeoPrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Teilen",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }
        }
    }
}
