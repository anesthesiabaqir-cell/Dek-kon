package com.example.ui.components

import android.util.LruCache
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextIndent
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.WordHistoryEntity
import com.example.data.model.extractVerbQuickDetails
import org.json.JSONObject
import com.example.ui.theme.GeoBorder
import com.example.ui.theme.GeoFemininBg
import com.example.ui.theme.GeoFemininText
import com.example.ui.theme.GeoMaskulinBg
import com.example.ui.theme.GeoMaskulinText
import com.example.ui.theme.GeoNeutrumBg
import com.example.ui.theme.GeoNeutrumText
import com.example.ui.theme.GeoOnPrimaryContainer
import com.example.ui.theme.GeoOnSecondaryContainer
import com.example.ui.theme.GeoOnSurface
import com.example.ui.theme.GeoOnSurfaceVariant
import com.example.ui.theme.GeoOutline
import com.example.ui.theme.GeoPluralBg
import com.example.ui.theme.GeoPluralText
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryContainer
import com.example.ui.theme.GeoSecondaryContainer
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceVariant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal object HistoryFormatterCache {
    private val dateCache = LruCache<Long, String>(1024)
    private val shortDateCache = LruCache<Long, String>(1024)
    private val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
    private val shortDateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

    fun formatDate(timestamp: Long): String {
        val cached = dateCache.get(timestamp)
        if (cached != null) return cached
        val formatted = synchronized(dateFormat) {
            dateFormat.format(Date(timestamp))
        }
        dateCache.put(timestamp, formatted)
        return formatted
    }

    fun formatShortDate(timestamp: Long): String {
        val cached = shortDateCache.get(timestamp)
        if (cached != null) return cached
        val formatted = synchronized(shortDateFormat) {
            shortDateFormat.format(Date(timestamp))
        }
        shortDateCache.put(timestamp, formatted)
        return formatted
    }
}

internal data class HistoryBadgeInfo(
    val bg: Color,
    val text: Color,
    val label: String
)

@Composable
internal fun getBadgeInfo(isVerb: Boolean, gender: String): HistoryBadgeInfo {
    if (isVerb) return remember { HistoryBadgeInfo(Color(0xFFFEF3C7), Color(0xFFB45309), "VERB") }

    return remember(gender) {
        when (gender.lowercase(Locale.ROOT)) {
            "maskulin", "masculine", "der" -> HistoryBadgeInfo(GeoMaskulinBg, GeoMaskulinText, "MASKULIN")
            "feminin", "feminine", "die" -> HistoryBadgeInfo(GeoFemininBg, GeoFemininText, "FEMININ")
            "neutrum", "neuter", "das" -> HistoryBadgeInfo(GeoNeutrumBg, GeoNeutrumText, "NEUTRUM")
            else -> HistoryBadgeInfo(GeoPluralBg, GeoPluralText, "PLURAL")
        }
    }
}

@Composable
fun HistoryHeaderRow(
    filteredCount: Int,
    hasItems: Boolean,
    onRequestClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.History,
                contentDescription = null,
                tint = GeoPrimary,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = "Suchverlauf",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = GeoOnSurface,
                maxLines = 1,
                softWrap = false
            )
            if (hasItems) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(GeoPrimaryContainer)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "$filteredCount",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = GeoOnPrimaryContainer
                    )
                }
            }
        }

        if (hasItems) {
            TextButton(
                onClick = onRequestClear,
                modifier = Modifier.testTag("clear_history_button")
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Verlauf leeren",
                    modifier = Modifier.size(16.dp),
                    tint = GeoOnSurfaceVariant
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Leeren",
                    style = MaterialTheme.typography.labelMedium,
                    color = GeoOnSurfaceVariant,
                    maxLines = 1,
                    softWrap = false
                )
            }
        }
    }
}

@Composable
fun HistorySearchBar(
    searchQuery: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(GeoSurfaceVariant)
                .border(1.dp, GeoBorder, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                tint = GeoPrimary,
                modifier = Modifier.size(20.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.CenterStart
            ) {
                if (searchQuery.isEmpty()) {
                    Text(
                        text = "Verlauf durchsuchen",
                        fontSize = 16.sp,
                        color = GeoOnSurfaceVariant,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                BasicTextField(
                    value = searchQuery,
                    onValueChange = onQueryChange,
                    singleLine = true,
                    maxLines = 1,
                    textStyle = TextStyle(
                        fontSize = 16.sp,
                        color = GeoOnSurface
                    ),
                    cursorBrush = SolidColor(GeoPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("history_search_input_field")
                )
            }

            if (searchQuery.isNotEmpty()) {
                IconButton(
                    onClick = { onQueryChange("") },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Sucheingabe löschen",
                        tint = GeoOutline,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun HistoryFilterPills(
    selectedFilterIndex: Int,
    onFilterChanged: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        listOf("Alle", "Nomen", "Verben").forEachIndexed { index, title ->
            val isSelected = selectedFilterIndex == index
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) GeoPrimary else GeoSurfaceVariant)
                    .clickable { onFilterChanged(index) }
                    .padding(horizontal = 12.dp, vertical = 5.dp)
                    .testTag("history_filter_$index"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) Color.White else GeoOnSurfaceVariant,
                    maxLines = 1,
                    softWrap = false
                )
            }
        }
    }
}

@Composable
fun HistoryEmptyCard(
    searchQuery: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, GeoBorder),
        colors = CardDefaults.cardColors(containerColor = GeoSurfaceVariant.copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.History,
                contentDescription = null,
                modifier = Modifier.size(32.dp),
                tint = GeoOutline
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (searchQuery.isNotBlank()) "Keine Treffer" else "Kein Suchverlauf",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = GeoOnSurface
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = if (searchQuery.isNotBlank()) {
                    "Kein Eintrag im Verlauf entspricht \"$searchQuery\"."
                } else {
                    "Gesuchte Nomen und Verben erscheinen hier zur schnellen Wiederverwendung."
                },
                style = MaterialTheme.typography.bodySmall,
                color = GeoOnSurfaceVariant
            )
        }
    }
}

@Composable
fun ClearHistoryConfirmDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GeoSurface,
        icon = {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error
            )
        },
        title = {
            Text(
                "Suchverlauf leeren",
                fontWeight = FontWeight.Bold,
                color = GeoOnSurface
            )
        },
        text = {
            Text(
                "Möchten Sie wirklich alle Einträge aus dem Verlauf entfernen?",
                color = GeoOnSurfaceVariant
            )
        },
        confirmButton = {
            TextButton(
                onClick = onConfirm,
                modifier = Modifier.testTag("confirm_clear_history")
            ) {
                Text("Löschen", color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Abbrechen", color = GeoPrimary)
            }
        }
    )
}

@Composable
fun DeleteHistoryItemConfirmDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GeoSurface,
        icon = {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error
            )
        },
        title = {
            Text(
                "Eintrag löschen?",
                fontWeight = FontWeight.Bold,
                color = GeoOnSurface
            )
        },
        text = {
            Text(
                "Möchten Sie diesen Eintrag aus dem Verlauf entfernen?",
                color = GeoOnSurfaceVariant
            )
        },
        confirmButton = {
            TextButton(
                onClick = onConfirm,
                modifier = Modifier.testTag("confirm_delete_history_item")
            ) {
                Text("Löschen", color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Abbrechen", color = GeoPrimary)
            }
        }
    )
}

fun LazyListScope.historySectionItems(
    historyList: List<WordHistoryEntity>,
    filteredList: List<WordHistoryEntity>,
    selectedFilterIndex: Int,
    historySearchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onFilterChanged: (Int) -> Unit,
    onSelectWord: (WordHistoryEntity) -> Unit,
    onDeleteItem: (Long) -> Unit,
    onRequestClearAll: () -> Unit,
    onSpeak: (String) -> Unit
) {
    item(key = "history_header_row") {
        HistoryHeaderRow(
            filteredCount = filteredList.size,
            hasItems = historyList.isNotEmpty(),
            onRequestClear = onRequestClearAll
        )
    }

    item(key = "history_search_box") {
        HistorySearchBar(
            searchQuery = historySearchQuery,
            onQueryChange = onSearchQueryChange
        )
    }

    if (historyList.isNotEmpty()) {
        item(key = "history_filter_pills") {
            HistoryFilterPills(
                selectedFilterIndex = selectedFilterIndex,
                onFilterChanged = onFilterChanged
            )
        }
    }

    if (filteredList.isEmpty()) {
        item(key = "history_empty_card") {
            HistoryEmptyCard(searchQuery = historySearchQuery)
        }
    } else {
        items(
            items = filteredList,
            key = { it.id },
            contentType = { "history_item_card" }
        ) { item ->
            HistoryItemCard(
                item = item,
                onClick = { onSelectWord(item) },
                onDelete = { onDeleteItem(item.id) },
                onSpeak = onSpeak,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
            )
        }
    }
}

@Composable
fun HistorySection(
    historyList: List<WordHistoryEntity>,
    onSelectWord: (WordHistoryEntity) -> Unit,
    onDeleteItem: (Long) -> Unit,
    onClearAll: () -> Unit,
    onSpeak: (String) -> Unit = {},
    onExportAll: () -> Unit = {},
    selectedFilterIndex: Int = 0,
    onFilterChanged: (Int) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showClearConfirmDialog by remember { mutableStateOf(false) }
    var itemToDeleteId by remember { mutableStateOf<Long?>(null) }
    var historySearchQuery by rememberSaveable { mutableStateOf("") }

    BackHandler(enabled = showClearConfirmDialog || itemToDeleteId != null) {
        showClearConfirmDialog = false
        itemToDeleteId = null
    }

    val filteredList by produceState(
        initialValue = historyList,
        key1 = historyList,
        key2 = selectedFilterIndex,
        key3 = historySearchQuery
    ) {
        withContext(Dispatchers.Default) {
            val typeFiltered = when (selectedFilterIndex) {
                1 -> historyList.filter { !it.type.equals("Verb", ignoreCase = true) }
                2 -> historyList.filter { it.type.equals("Verb", ignoreCase = true) }
                else -> historyList
            }
            value = if (historySearchQuery.isBlank()) {
                typeFiltered
            } else {
                val query = historySearchQuery.trim().lowercase(Locale.ROOT)
                typeFiltered.filter { item ->
                    item.word.lowercase(Locale.ROOT).contains(query) ||
                    item.genderArticle.lowercase(Locale.ROOT).contains(query) ||
                    item.meaningEnglish.lowercase(Locale.ROOT).contains(query)
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        HistoryHeaderRow(
            filteredCount = filteredList.size,
            hasItems = historyList.isNotEmpty(),
            onRequestClear = { showClearConfirmDialog = true }
        )

        HistorySearchBar(
            searchQuery = historySearchQuery,
            onQueryChange = { historySearchQuery = it }
        )

        if (historyList.isNotEmpty()) {
            HistoryFilterPills(
                selectedFilterIndex = selectedFilterIndex,
                onFilterChanged = onFilterChanged
            )
        }

        if (filteredList.isEmpty()) {
            HistoryEmptyCard(searchQuery = historySearchQuery)
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                filteredList.forEach { item ->
                    key(item.id) {
                        HistoryItemCard(
                            item = item,
                            onClick = { onSelectWord(item) },
                            onDelete = { itemToDeleteId = item.id },
                            onSpeak = onSpeak
                        )
                    }
                }
            }
        }
    }

    if (showClearConfirmDialog) {
        ClearHistoryConfirmDialog(
            onConfirm = {
                onClearAll()
                showClearConfirmDialog = false
            },
            onDismiss = { showClearConfirmDialog = false }
        )
    }

    itemToDeleteId?.let { id ->
        DeleteHistoryItemConfirmDialog(
            onConfirm = {
                onDeleteItem(id)
                itemToDeleteId = null
            },
            onDismiss = { itemToDeleteId = null }
        )
    }
}

@Composable
fun HistoryItemCard(
    item: WordHistoryEntity,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onSpeak: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isVerb = remember(item.type) { item.type.equals("Verb", ignoreCase = true) }
    val badge = getBadgeInfo(isVerb, item.gender)
    val formattedDate = remember(item.timestamp) { HistoryFormatterCache.formatDate(item.timestamp) }

    val verbDetails = remember(item, isVerb) {
        if (isVerb) extractVerbQuickDetails(item) else null
    }

    val pluralText = remember(item.rawJsonResult, isVerb) {
        if (isVerb) "" else extractPluralForm(item.rawJsonResult)
    }

    val singularDisplay = remember(isVerb, item.genderArticle, item.word) {
        if (!isVerb && item.genderArticle.isNotBlank()) {
            "${item.genderArticle} ${item.word}"
        } else {
            item.word
        }
    }

    if (isVerb) {
        // 🎯 New Card Design for Verbs (Permanent Solution)
        // Fixed/flexible min 160dp height, white container, 12dp start/end padding, 8dp top padding, 14dp bottom padding
        // 4 clearly separated rows with 1dp light gray dividers (#EEEEEE)
        Card(
            modifier = modifier
                .fillMaxWidth()
                .heightIn(min = 160.dp)
                .graphicsLayer { clip = false }
                .clickable(onClick = onClick)
                .testTag("history_item_${item.id}"),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Color(0xFFEEEEEE)),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 14.dp)
            ) {
                // Element 1: Header (word) - 32dp height, bold font, distinctive color
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.weight(1f, fill = false),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = item.word,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E3A8A)
                            ),
                            maxLines = 1,
                            softWrap = false
                        )
                    }

                    // Quick action icons (speak and delete) on top right
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(
                            onClick = { onSpeak(item.word) },
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("pronounce_history_${item.id}")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Wort anhören",
                                tint = Color(0xFF9E9E9E),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("delete_history_item_${item.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Eintrag löschen",
                                tint = Color(0xFF9E9E9E),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Thin horizontal divider: 2dp top margin, 1dp height, #EEEEEE
                Spacer(modifier = Modifier.height(2.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color(0xFFEEEEEE))
                )

                // Element 2: Conjugations row (German) - 40dp height, scrollable horizontally, dark blue text, 14sp font
                Spacer(modifier = Modifier.height(4.dp))
                val conjugationsScrollState = rememberScrollState()
                val conjugationsText = remember(verbDetails) {
                    if (verbDetails != null) {
                        val items = mutableListOf<String>()
                        if (verbDetails.auxiliary.isNotBlank()) items.add(verbDetails.auxiliary)
                        if (verbDetails.praeteritum.isNotBlank()) items.add(verbDetails.praeteritum)
                        if (verbDetails.partizip1.isNotBlank()) {
                            val p1 = if (verbDetails.partizip1.startsWith("Part I", ignoreCase = true)) verbDetails.partizip1 else "Part I: ${verbDetails.partizip1}"
                            items.add(p1)
                        }
                        if (verbDetails.partizip2.isNotBlank()) {
                            val p2 = if (verbDetails.partizip2.startsWith("Part II", ignoreCase = true)) verbDetails.partizip2 else "Part II: ${verbDetails.partizip2}"
                            items.add(p2)
                        }
                        if (verbDetails.verbType.isNotBlank()) items.add(verbDetails.verbType)
                        if (verbDetails.separable.isNotBlank()) items.add(verbDetails.separable)
                        if (verbDetails.caseObject.isNotBlank()) items.add(verbDetails.caseObject)
                        items.joinToString(" · ")
                    } else {
                        ""
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .horizontalScroll(conjugationsScrollState),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (conjugationsText.isNotBlank()) conjugationsText else "—",
                        style = TextStyle(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF1E3A8A) // Dark blue text
                        ),
                        maxLines = 1,
                        softWrap = false
                    )
                }

                // Thin horizontal divider: 2dp top margin, 1dp height, #EEEEEE
                Spacer(modifier = Modifier.height(2.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color(0xFFEEEEEE))
                )

                // Element 3: Translation row (English) - 40dp height, scrollable horizontally, dark green text, 14sp font
                Spacer(modifier = Modifier.height(4.dp))
                val translationScrollState = rememberScrollState()
                val translationText = remember(verbDetails?.englishMeaning) {
                    val raw = verbDetails?.englishMeaning.orEmpty().trim()
                    val clean = if (raw.startsWith("Eng.:", ignoreCase = true)) {
                        raw.substringAfter("Eng.:").trim()
                    } else if (raw.startsWith("Eng:", ignoreCase = true)) {
                        raw.substringAfter("Eng:").trim()
                    } else {
                        raw
                    }
                    if (clean.contains(",")) {
                        clean.split(",").map { it.trim() }.filter { it.isNotBlank() }.joinToString(" · ")
                    } else {
                        clean
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .horizontalScroll(translationScrollState),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (translationText.isNotBlank()) "Eng.: $translationText" else "Eng.: —",
                        style = TextStyle(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF1B5E20) // Dark green text
                        ),
                        maxLines = 1,
                        softWrap = false
                    )
                }

                // Thin horizontal divider: 2dp top margin, 1dp height, #EEEEEE
                Spacer(modifier = Modifier.height(2.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color(0xFFEEEEEE))
                )

                // Element 4: Metadata row - 28dp height, gray text, 12sp font
                Spacer(modifier = Modifier.height(4.dp))
                val shortDate = remember(item.timestamp) {
                    HistoryFormatterCache.formatShortDate(item.timestamp)
                }
                val pastTenseDisplay = remember(verbDetails) {
                    if (verbDetails == null) return@remember ""
                    val form = verbDetails.praeteritum.trim().ifBlank { verbDetails.partizip2.trim() }
                    if (form.isNotBlank()) {
                        if (form.startsWith("Prät.", ignoreCase = true)) form else "Prät.: $form"
                    } else {
                        ""
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left / Info badges: Date, Category badge (verb in yellow), Präteritum
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 1. Date with emoji: 📅 08.09.2026
                        Text(
                            text = "📅 $shortDate",
                            style = TextStyle(
                                fontSize = 12.sp,
                                color = Color(0xFF757575) // Light gray text
                            ),
                            maxLines = 1,
                            softWrap = false
                        )

                        // 2. verb label: styled as gender labels from screenshot (yellow #FFD700)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFFFF9C4)) // soft yellow background
                                .border(1.dp, Color(0xFFFFD700).copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "verb",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFB45309), // Warm amber/gold for crisp legibility
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                letterSpacing = 0.4.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        // 3. Past tense label (Präteritum): Prät.: ...
                        if (pastTenseDisplay.isNotBlank()) {
                            Text(
                                text = pastTenseDisplay,
                                style = TextStyle(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF424242) // Dark gray text
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }
        }
    } else {
        // Noun 2-row Layout
        Card(
            modifier = modifier
                .fillMaxWidth()
                .graphicsLayer { clip = false }
                .clickable(onClick = onClick)
                .testTag("history_item_${item.id}"),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, GeoBorder.copy(alpha = 0.6f)),
            colors = CardDefaults.cardColors(containerColor = GeoSurfaceVariant),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                // Top row: Singular (left) | Plural (right)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.weight(1f, fill = false),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        DynamicTextView(
                            text = singularDisplay,
                            minTextSize = 11f,
                            maxTextSize = 16f,
                            paddingStart = 0.dp,
                            paddingEnd = 4.dp,
                            fontWeight = FontWeight.Bold,
                            color = GeoOnSurface,
                            textStyle = MaterialTheme.typography.bodyLarge
                        )
                    }

                    if (pluralText.isNotBlank()) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier.weight(1f, fill = false),
                            contentAlignment = Alignment.CenterEnd
                        ) {
                            DynamicTextView(
                                text = pluralText,
                                minTextSize = 11f,
                                maxTextSize = 15f,
                                paddingStart = 4.dp,
                                paddingEnd = 0.dp,
                                fontWeight = FontWeight.Medium,
                                color = GeoOnSurfaceVariant,
                                textStyle = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Bottom row: Category badge · Timestamp (left) | Speaker & Trash icons (fixed right)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(badge.bg)
                                .border(1.dp, GeoBorder.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = badge.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = badge.text,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                letterSpacing = 0.4.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        Text(
                            text = "·",
                            style = MaterialTheme.typography.labelSmall,
                            color = GeoOutline,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = formattedDate,
                            style = MaterialTheme.typography.labelSmall,
                            color = GeoOutline,
                            fontSize = 11.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        IconButton(
                            onClick = {
                                val phrase = if (item.genderArticle.isNotBlank()) {
                                    "${item.genderArticle} ${item.word}"
                                } else {
                                    item.word
                                }
                                onSpeak(phrase)
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("pronounce_history_${item.id}")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Wort anhören",
                                tint = Color(0xFF9E9E9E),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("delete_history_item_${item.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Eintrag löschen",
                                tint = GeoOutline,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun extractPluralForm(rawJson: String): String {
    if (rawJson.isBlank()) return ""
    return try {
        val json = JSONObject(rawJson)
        val pluralNoun = json.optString("pluralNoun").trim()
        if (pluralNoun.isNotBlank()) return pluralNoun
        val pluralObj = json.optJSONObject("plural")
        val nominativObj = pluralObj?.optJSONObject("nominativ")
        val definite = nominativObj?.optString("definite").orEmpty().trim()
        if (definite.isNotBlank()) return definite
        nominativObj?.optString("noArticle").orEmpty().trim()
    } catch (e: Exception) {
        ""
    }
}

